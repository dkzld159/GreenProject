package com.example.demo.repository;

import java.util.Optional;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Product;
import com.example.demo.entity.ProductDetail;
import com.example.demo.entity.Provider;

@SpringBootTest
class ProductRepositoryTest {
		
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductDetailRepository productDetailRepository;
	
	@Autowired
	ProviderRepository providerRepository;
	
	
	@Test
	void cascadeTest() { //영속성 전이
		Provider provider = savedProvider("새로운 공급업체");
		
		Product product1 = savedProduct("상품1", 10000);
		Product product2 = savedProduct("상품2", 10000);
		Product product3 = savedProduct("상품3", 10000);
		
		//연관관계 설정
		product1.setProvider(provider);
		product2.setProvider(provider);
		product3.setProvider(provider);
		
		provider.getProductlist().addAll(Lists.newArrayList(product1,product2,product3));
		
		providerRepository.save(provider);
		
	}
	
	
	private Provider savedProvider(String name) {
		Provider provider = new Provider();
		provider.setName(name);
		
		return provider;
	}


	private Product savedProduct(String name, int price) {
		Product product = new Product();
		product.setPname(name);
		product.setPrice(price);
		
		return product;
	}

	
	@Test
	void relationshipTest1() {
		//테스트 데이터 생성
		Provider provider = new Provider();
		provider.setName("00물산");
		providerRepository.save(provider);
		
		Product product = new Product();
		product.setPname("가위");
		product.setPrice(10000);
		product.setProvider(provider);
		
		productRepository.save(product);
		
		System.out.println("product : "+ productRepository.findById(1));
		System.out.println("provider : "+ productRepository.findById(1).get().getProvider());
	}
	
	@Test
	void saveAndReadTest() {
		Product product = new Product();
		
		product.setPname("스프링부트 JPA");
		product.setPrice(5000);
		productRepository.save(product);
		
		ProductDetail productDetail = new ProductDetail();
		productDetail.setProduct(product);
		productDetail.setDescrition("스프링 부트와  JPA를 함꼐 볼 수 있는책 ");
	
		productDetailRepository.save(productDetail);
		
		
		//조회
		Optional<ProductDetail> result = productDetailRepository.findById(productDetail.getId());
		ProductDetail pd= result.get();
		//result.get()은 Optional<ProductDetail>에서 실제 ProductDetail 객체를 가져옵니다.
		System.out.println("savedProduct : "+pd.getProduct());
		
		System.out.println("saveProductDetail" 
				+ productDetailRepository.findById(productDetail.getId()).get());
		
		System.out.println("saveProduct상품명===="+ product.getPname());
		
		
		
	}

}
