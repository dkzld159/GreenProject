package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.entity.Product;
import com.example.demo.entity.ProductDetail;
import com.example.demo.entity.Team;
import com.example.demo.entity.member1;
import com.example.demo.repository.TeamRepository;
import com.example.demo.repository.member1Repository;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;



@Controller
@RequestMapping("/team")
public class TeamController {

	@Autowired
	member1Repository memberRepository;
	
	@Autowired
	TeamRepository teamRepository;
	
	@RequestMapping("/registForm")
	public String registForm(Model model) {
		member1 member = new member1();
		model.addAttribute("member",member);
		return "/team/registForm";
	}
	
	
	@RequestMapping("/registm")
	public String regist(member1 member) {
		//System.out.println("sdfsdf" +name);
		List<member1> memList = new ArrayList<>();
 		memberRepository.saveAll(memList);
		return "redirect:/team/list";
	}
	
	
	@RequestMapping("/list")
	public String requestMethodName(member1 member1, Model model) {
		
		List<member1> memList = memberRepository.findAll();
		model.addAttribute("list",memList);
		
		return "/team/list";
	}
	
	@RequestMapping("/detail/{mno}")
	public String detail(@PathVariable("mno") int mno , Model model) {
		Optional<member1> result = memberRepository.findById(mno);
		
		member1 m =result.get();
		
        model.addAttribute("member", m);
		
		return "/team/detail";
	}
	
	
	@RequestMapping("/detailForm")
	public String detailForm(@RequestParam("mno") int mno, @RequestParam("teamname") Team team) {
	    System.out.println("sdfsdfsdf" +mno);

	        // 팀이 존재하면, 새로운 member1 객체 생성
	        member1 member = new member1();
	        member.setMno(mno);  // 전달된 mno 값을 설정
	        member.setTeam(team);  // 조회된 Team 객체 설정

	      
	        memberRepository.save(member);
	    

	    // 리다이렉트하여 목록 페이지로 이동
	    return "redirect:/team/list";
	}
	
	
	
	
}
