package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.checkerframework.checker.lock.qual.NewObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dto.ProductDto;
import com.example.demo.entity.Product;
import com.example.demo.entity.ProductDetail;
import com.example.demo.repository.ProductDetailRepository;
import com.example.demo.repository.ProductRepository;


@Controller
public class Mycontroller {

	@Autowired
	ProductRepository productRepository;
	
	
	@Autowired
	ProductDetailRepository productDetailRepository;
	
	
	@RequestMapping("/")
	public String root() {
		return "/team/main";
	}
	
	
	@RequestMapping("/registForm")
	public String reistForm(Model model) {
		Product product = new Product();
		model.addAttribute("product",product);
		return "registForm";
	}
	
	@RequestMapping("/regist")
	public String regist(Product product) {
	 ;        // ProductDetail의 product 필드 설정

	    // 연관된 객체들 저장
	    productRepository.save(product);

	    return "redirect:/list";  
	}
	
	
	@RequestMapping("/list")
	public String list(Product product, Model model) {
		
		List<Product> proList =productRepository.findAll();
		List<ProductDetail> proList1 =productDetailRepository.findAll();
		model.addAttribute("list", proList);
		model.addAttribute("list1", proList1);
		return "list";
	}
	
	
	@RequestMapping("/detail/{pno}")
	public String detail(@PathVariable("pno") int pno , Model model) {
		Optional<Product> result = productRepository.findById(pno);
		Optional<ProductDetail> resul1t = productDetailRepository.findById(pno);
		
		Product p = result.get();
		ProductDetail pd = resul1t.get();
		
		// 모델에 각각 다른 이름으로 추가
        model.addAttribute("product", p);
        model.addAttribute("productDetail", pd);
		
		return "detail";
	}
	
	
	@RequestMapping("/detailForm")
	public String detailForm(ProductDetail productdetail) {
		
		productDetailRepository.save(productdetail);
		
		return "redirect:/list";
	}
	
}
