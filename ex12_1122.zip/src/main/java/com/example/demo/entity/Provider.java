package com.example.demo.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table (name = "tbl_provider")
@Builder
@Getter
@ToString
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Provider { //공급업체
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name;
	
	//너주인해 mappedBy
	//부모와 자식,  부모는 provider  //한부모(provider)가 여러자식(product)을 가질수있으니
	//다쪽이 자식, 주인, //1이 부모 
	@OneToMany(mappedBy = "provider" ,cascade = CascadeType.PERSIST)
	//eager즉시반영,lazy지연반영
	//연관관계주인은 ManytoOne
	private List<Product> productlist = new ArrayList<>();
	
	
	
	
	
}
