package com.example.demo.entity;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table (name = "tbl_team")
@Builder
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Team {
 //1이고 부모, 여러 멤버를 가질수 있다
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tno;
	
	@Column(nullable = false)
	private String name;
	
	@OneToMany(mappedBy = "team")  // "team"은 Member 클래스에서의 필드명
    private List<member1> members = new ArrayList<>();  // 팀에 속한 멤버들
    
    
    
	
	
}
