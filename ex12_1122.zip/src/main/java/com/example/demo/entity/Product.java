package com.example.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Version;
import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table (name = "tbl_product")
@Builder
@Getter
@ToString
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Transactional
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int pno;
	@Column(nullable =  false)
	private String pname;
	@Column(nullable =  false)
	private int price;
	
	//(연관관계의 주인이 누구냐 할떄  양뱡향설정에서 mppaedBy 사용) 외래키를 갖고있는애를 주인으로 삼겠다.
	@OneToOne(mappedBy = "product")
	//@ToString.Exclude
	private ProductDetail productDetail;
	
	//공급자랑 외래키 설정 
	@ManyToOne
	@JoinColumn(name ="provider_id")
	private Provider provider;
	
}
