package com.example.demo.dto;

import org.checkerframework.checker.lock.qual.NewObject;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
@NewObject
public class ProductDto {

	
	private int pno;
	private String pname;
	private int price;

	
	
}
