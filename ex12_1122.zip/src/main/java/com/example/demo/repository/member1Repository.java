package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.member1;

public interface member1Repository extends JpaRepository<member1, Integer>{

}
