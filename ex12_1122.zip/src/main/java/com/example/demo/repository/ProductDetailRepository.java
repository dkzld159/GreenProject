package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entity.Product;
import com.example.demo.entity.ProductDetail;

public interface ProductDetailRepository extends JpaRepository<ProductDetail, Integer>{

	
}
