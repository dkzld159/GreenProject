package com.example.demo.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.MemberDto;
import com.example.demo.dto.MemberList;



@RestController
@RequestMapping("/api/v1/post-api")
public class PostController {

	
//	@Autowired
//	MemberList memberlist;
	
	@PostMapping("/domain")
	public String PostEx() {
		return "Hello Post API";
	}
	
	MemberList memberlists = new MemberList();
	 // http://localhost:8089/api/v1/post-api/member
    @PostMapping("/member")
    public String postMember(@RequestBody Map<String, Object> postData){

        StringBuilder sb = new StringBuilder();

        postData.entrySet().forEach(map -> {
           sb.append(map.getKey() + " : " + map.getValue() + "\n");
        });

        memberlists.getMembers().add(new MemberDto(
        							String.valueOf(postData.get("name")), 
        							String.valueOf(postData.get("email")), 
        							String.valueOf(postData.get("tel")),
        							Integer.valueOf(String.valueOf(postData.get("age")))
        							));
        return sb.toString();
    }
	
    

    // http://localhost:8089/api/v1/get-api/fetching?name=value&email=value2
    @GetMapping("/fetching/{name}")
    public String getFetching(@PathVariable("name") String name) {
        return memberlists.getMember(name).toString();
    }

    
}

