package com.example.demo.dto;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class MemberList {
    private List<MemberDto> members;

    public MemberList() {
    	members = new ArrayList<MemberDto>();
        members.add(new MemberDto("aaa","a1234","홍길동",30));
        members.add(new MemberDto("bbb","b1234","김삿갓",20));
        members.add(new MemberDto("ccc","c1234","이순신",40));
    }
    
    public MemberDto getMember(String name){
        for(int i = 0; i < members.size(); i++){
            if(members.get(i).getName().equals(name)){
                return members.get(i);
            }
        }
        return null;
    }
    
}