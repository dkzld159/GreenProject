package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.MemberDto;
import com.example.demo.dto.MemberList;

import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping("/api/v1/get-api")
public class GetController {
	
	//http://localhost:8080/api/v1/get-api/hello
	@RequestMapping(value = "/hello", method=RequestMethod.GET)
	public String getHello() {
		return "Hello World";
	}
	
	//http://localhost:8080/api/v1/get-api/name
	@GetMapping("/name")
	public String getName() {
		return "James";
	}
	
	
	//http://localhost:8080/api/v1/get-api/variable1/{문자열}
	@RequestMapping("variable1/{variable}")
	public String getVariable1(@PathVariable("variable") String variable) {
		return variable;
	}
	
	
	//http://localhost:8080/api/v1/get-api/requset1?name=value&email=value2
	@GetMapping("/requset1")
	public String getMethodName(@RequestParam("name") String name, @RequestParam("email") String email) {
	    return "name: " + name + ", email: " + email;
	}
	
	
	//파라미터가 넘어오는건 아는데 어떤게 넘어올지 모를떄 , 유연하게 짜야할때 map을 이용하면 된다.
	//http://localhost:8080/api/v1/get-api/requset2?name=value&email=value2
	@GetMapping("/requset2")
	public String getMethodName2(@RequestParam Map<String, String> param) {
	    StringBuilder sb = new StringBuilder();
	    param.entrySet().forEach(map -> {
	        sb.append(map.getKey() + " : " + map.getValue() + "\n");
	    });
	    return sb.toString();
	}
	
	
	//http://localhost:8080/api/v1/get-api/requset3?name=value&email=value2
	@GetMapping("/requset3")
	public String getRequestParam3(MemberDto memberDto) {
		return memberDto.toString();
	}
	
	//멤버 정보를 갖고있는 클래스 make
	//멤버에는 3개 정도의 정보
	//명사를 쓴다. url작성 규칙에 따라서 데이터를 출력하는거 완성시킨다.
	//http://localhost:8080/api/v1/get-api/get-Member
	@GetMapping("/get-Member")
	public String getMember(MemberList memberDto) {
		return memberDto.toString();
	}
	
	
		
}
