package com.example.demo.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.MemberList;

@RestController
@RequestMapping("/api/v1/put-api")
public class PutController {

    MemberList membersDto = new MemberList();

    @PutMapping("/member/{name}")
    public String putMember(@PathVariable("name") String name, @RequestBody Map<String, Object> postData) {

        StringBuilder sb = new StringBuilder();

        postData.entrySet().forEach(map -> {
            sb.append(map.getKey() + " : " + map.getValue() + "\n");
        });

        String newName = String.valueOf(postData.get("name"));
        String newEmail = String.valueOf(postData.get("email"));
        String tel = String.valueOf(postData.get("tel"));
        int age = Integer.valueOf(String.valueOf(postData.get("age")));

        membersDto.getMember(name).setEmail(newEmail);
        membersDto.getMember(name).setName(newName);
        membersDto.getMember(name).setTel(tel);
        membersDto.getMember(name).setAge(age);
        

        return membersDto.getMember(newName).toString();
    }


}
