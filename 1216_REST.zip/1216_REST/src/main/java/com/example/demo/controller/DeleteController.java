package com.example.demo.controller;

import java.util.Map;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.MemberDto;
import com.example.demo.dto.MemberList;

public class DeleteController {


@RestController
@RequestMapping("/api/v1/delete-api")
public class PutController {

    MemberList membersDto = new MemberList();
    
    @PutMapping("/member/{name}")
    public String putMember(@PathVariable("name") String name) {
    	membersDto.getMembers().removeIf(MemberDto -> MemberDto.getName().equals(name));
        return membersDto.toString();
    }

	
	}

}



