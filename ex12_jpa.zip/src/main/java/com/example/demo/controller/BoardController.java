package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dto.BoardDto;
import com.example.demo.entity.Board;
import com.example.demo.repository.BoardRepository;

@Controller
@RequestMapping("/board")
public class BoardController {

	@Autowired
	BoardRepository boardRepository;
		@RequestMapping("/regForm")
		public String regFrom() {
			
			return "board/regForm";
		}
		
		@RequestMapping("/regist")
		public String regist(BoardDto boardDto) {
			
			return "redirect:/board/list";
		}
		
		@RequestMapping("/list")
		public String list(Model model) {
			
			
			List<Board>	list =boardRepository.findAll();
			model.addAttribute("list",list);
			System.out.println(list+"sdfsdfsdf");
			return "/board/list";
		}
}
