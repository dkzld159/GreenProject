package com.example.demo.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="tbl_board1")
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Getter
@ToString
public class Board extends BaseEntity{
	//날짜를 하나의 클래스에 위임을 하고 받아쓰는거
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) //autoincrement
	private int bno;
	
	private String title;
	private String content;
	private String writer;
}
