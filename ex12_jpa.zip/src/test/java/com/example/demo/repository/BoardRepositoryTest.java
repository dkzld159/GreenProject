package com.example.demo.repository;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.entity.Board;

@SpringBootTest
class BoardRepositoryTest {
	@Autowired
	BoardRepository boardRepository;
	
	//@Test
	void testInsert() {
		Board board = Board.builder()
				.title("test 제목1")
				.content("test 내용1")
				.writer("user01")
				.build();
		Board result =boardRepository.save(board);
		System.out.println(result);
	}
	
	@Test
	void testUpdate() {
		Board board = Board.builder()
				.bno(1)
				.title("test 수정222")
				.content("test 수정222")
				.writer("user01")
				.build();
		Board result =boardRepository.save(board);
		System.out.println(result);
	}

}
