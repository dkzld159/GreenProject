package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dao.IMemberDao;
import com.example.demo.entity.Member;
import com.example.demo.service.MemberService;

@Controller
public class MyController {
	
	
	@Autowired
	MemberService mservice;
	
	@Autowired
	IMemberDao dao;
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@GetMapping("/")
	public String main() {
		return "main";
	}
	
	@GetMapping("/login")
	public String login() {
		return "/login";
	}
	
	@GetMapping("/admin/adminPage")  //쓴이유가 있어.
	public String adminPage() {
		return "/admin/adminPage";
	}
	
	@GetMapping("/registForm")
	public String registForm() {
		return "/registForm";
	}
	
	@PostMapping("/regist")
	public String regist(Member member) {
	String encodedPassword = bCryptPasswordEncoder.encode(member.getPassword());
		//패스워드 암호화
		member.setPassword(encodedPassword);
		member.setRole("ROLE_MEMBER");
		
		int result = mservice.insertMember(member);
		if(result == 1 ) {
			return "redirect:/login";
		}
		return "redirect:/main";
	}
	
	
	
	
	
}
