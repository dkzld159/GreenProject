package com.example.demo.secu;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IMemberDao;
import com.example.demo.entity.Member;

@Service //***역할 어노테이션 붙여줘야됨
public class CustomUserDetailsService implements UserDetailsService{

	private Member member; //디비에 들어있는 사용자 정보만 가능 
	@Autowired
	IMemberDao memberDao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Member member = memberDao.findByUsername(username);
		return new CustomUserDetails(member);
	}

	
	
	
}
