package com.example.demo.dao;

import com.example.demo.entity.Board;

public interface IBoardDao {

	public int regist(Board board);
	
}
