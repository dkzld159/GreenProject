package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IMemberDao;
import com.example.demo.entity.Member;

@Service
public class MemberService {

	@Autowired
	IMemberDao memberdao;
	
	 public int insertMember(Member member) {
		
		 
		 int result = memberdao.regist(member);
		 
		 return result;
	 }
}
