package com.example.demo.secu;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration //Spring의 설정 클래스
@EnableWebSecurity //Spring Security를 활성화하는 데 사용
public class SecurityConfig {
	
	@Bean //암호화하기 위한 객체 
	BCryptPasswordEncoder bCryptPasswordEncoder() {
		return new BCryptPasswordEncoder(); //생성이되면서 리턴 
	}
	
	@Bean //메서드의 객체
	
	//Spring Security는 SecurityFilterChain을 사용하여 이 규칙을 처리하고, 
	//인증되지 않은 사용자는 로그인 페이지로 리다이렉트되거나, 인증 절차를 요구하게 됩니다.
	public SecurityFilterChain SecurityFilterChain(HttpSecurity http) throws Exception{
		
		http
			.authorizeHttpRequests((auth) -> auth 
					//.anyRequest().permitAll() 모든것을 통과
					.requestMatchers("/","/registForm","/regist","/login").permitAll()
					.requestMatchers("/members/**").hasAnyRole("ADMIN","MEMBER")
					.requestMatchers("/admin/**").hasRole("ADMIN")
					.anyRequest().authenticated()  //권한이 없음. 인증요구해야됨.
					);
		http
			 .formLogin((auth) -> auth 
					 .loginPage("/login")
					 .loginProcessingUrl("/loginForm")
					 .defaultSuccessUrl("/")
					 .failureUrl("/login")
					 .permitAll()
					 );
		http 
			.csrf((auth) -> auth.disable());
		http	
			.logout(auth -> auth
					.logoutUrl("/logout")
					.logoutSuccessUrl("/")
					);
			 
		return http.build();
		
		//암호화된 유저랑 패스워드가 동일하면 시큐리티 컨텍스트에다가 사용자 정보 저장 (시큐리티가 관리) 
		//시큐리티 객체 : 시큐리티 컨텍스트 에다가는 디티오가 아니라 오쏘틱이라는 정장객체를 입고 저장해야됨
		//딱 맞는 가공된 클래스를 만들거임. 
		
	}
	
}
