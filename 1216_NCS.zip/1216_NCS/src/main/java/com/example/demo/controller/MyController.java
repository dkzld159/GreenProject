package com.example.demo.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dao.IMemberDao;
import com.example.demo.entity.Member;
import com.example.demo.service.MemberService;

import jakarta.servlet.http.HttpSession;

@Controller
public class MyController {
	
	
	@Autowired
	MemberService mservice;
	
	@Autowired
	IMemberDao dao;
	
	@Autowired
	BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@GetMapping("/")
	public String main(Principal principal, Model model) {
		 if (principal != null) {
		        model.addAttribute("principal", principal.getName()); // principal.getName()을 모델에 추가
		    } else {
		        model.addAttribute("principal", null); // principal이 null일 경우에도 처리
		    }
		    return "main";
	}
	
	//	public String main( HttpSession session) {
	
    //Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

    // MemberDto userDetails = (MemberDto) authentication.getPrincipal();

    //session.setAttribute("user", userDetails); // 로그인한 user정보를 session attribute로 저장.
	
	@GetMapping("/login")
	public String login() {
		return "/login";
	}
	
	@GetMapping("/admin/adminPage")  //쓴이유가 있어.
	public String adminPage() {
		return "/admin/adminPage";
	}
	
	@GetMapping("/registForm")
	public String registForm() {
		return "/registForm";
	}
	
	@PostMapping("/regist")
	public String regist(Member member) {
	String encodedPassword = bCryptPasswordEncoder.encode(member.getPassword());
		//패스워드 암호화
		member.setPassword(encodedPassword);
		member.setRole("ROLE_MEMBER");
		
		int result = mservice.insertMember(member);
		if(result == 1 ) {
			return "redirect:/login";
		}
		return "redirect:/main";
	}
	
	
	
	
	
}
