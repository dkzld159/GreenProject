package com.example.demo.controller;


import java.security.Principal;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.secu.CustomUserDetails;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/members")
public class MemberController {
	
	@GetMapping("/myPage1")
	public String myPage1(Model model) {
		//Authentication 시큐리티의 세션객체  customuserdetail은 authentication을 입어야됨.
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		CustomUserDetails userDetails = (CustomUserDetails)authentication.getPrincipal();
		
		model.addAttribute("username",userDetails.getName());
		model.addAttribute("password", userDetails.getPassword());
		model.addAttribute("name", userDetails.getName());
		model.addAttribute("role",userDetails.getRole());
		
		return "/members/myPage";
	}
	
	
	@GetMapping("/myPage2")
	public String mypage2(Model model, Principal principal) {
		//principal : 인증된 사용자 정보 중 중요한 유저네임 뽑음.
		model.addAttribute("username" , principal.getName());
		model.addAttribute("principal",principal.toString());
		
		return "/members/myPage";
	}
	
	
	@GetMapping("/myPage3")
	public String mypage3(Model model,@AuthenticationPrincipal  CustomUserDetails customUserDetails) {
		
		model.addAttribute("username",customUserDetails.getUsername());
		model.addAttribute("password",customUserDetails.getPassword());
		model.addAttribute("name",customUserDetails.getName());
		model.addAttribute("role",customUserDetails.getRole());
		return "/members/myPage";
	}
	
	
	
}
