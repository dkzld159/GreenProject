package com.example.demo.controller;


import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.IMemberDao;
import com.example.demo.domain.Member;



@RestController
@RequestMapping("/member-api")
public class MemberController2 {
	
	@Autowired
	IMemberDao imemberdao;

	//get http://localhost:8092/member-api/member?username=aaa
	@GetMapping("/member")
	public ResponseEntity<?> getMethod(@RequestParam(value = "username", required = false) String username) {
		//required = false 파라미터가 없어도 실행 된다 . . .
		 try {
	            if (username == null || username.isEmpty()) {
	                return ResponseEntity.badRequest()
	                        .body(Map.of(
	                        "status", 400,
	                        "message", "Invalid parameter : 'username' can't be null or empty."
	                ));
	            }

	            Member member = imemberdao.getMember(username);

	            if (member == null) {
	                return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                        .body(Map.of(
	                            "status", 404,
	                            "message", "Member not found. 'username' : " + username
	                        ));
	            }
	            return ResponseEntity.status(HttpStatus.ACCEPTED).body(member);
	        } catch (RuntimeException e) {
	            System.out.println("RuntimeException ...... " + e.getMessage());
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	                    .body(Map.of(
	                            "status", 500,
	                            "message", "An unexpected error occurred",
	                            "details", e.getMessage()
	                    ));
	        }
	}

	
	
	
	
	
	
	
	
	
	
	//Post http://localhost:8092/member-api/member
	@PostMapping("/member")
	public String postMember(@RequestBody Member member) {
		imemberdao.regMember(member);
		return "등록완료";
	}

	//put http://localhost:8092/member-api/member
	@PutMapping("/member")
	public String putMember(@RequestBody Member member) {
		imemberdao.updateMember(member);
		return "수정완료";
	}

	//delete http://localhost:8092/member-api/member?username=aaa
	@PutMapping("/member/{name}")
	public String delMember(@PathVariable("name") String name) {
		imemberdao.delMember(name);
		return "삭제완료";
	}

}
