package com.example.demo.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.dto.MemoDto;
import com.example.demo.entity.Memo;
import com.example.demo.repository.MemoRepository;

@Service
public class MemoService  implements IMemoService{

	 private final MemoRepository memoRepository;

    // MemoRepository를 생성자 주입 방식으로 주입
    @Autowired
    public MemoService(MemoRepository memoRepository) {
        this.memoRepository = memoRepository;
    }
	
	@Override
	public Memo register(MemoDto memoDto) {
		Memo memo = Memo.builder()
				.mno((long) memoDto.getMno())
				.memoText(memoDto.getMemoText())
				.writer(memoDto.getWriter())
				.build();
		return memoRepository.save(memo);
	}

	@Override
	public List<Memo> getList() {
		
		return memoRepository.findAll();
	}

	
	@Override
	public List<Memo> MyMemoList(String writer) {
		
		return memoRepository.findByWriter(writer);
	}

	@Override
	public Page<Memo> getPageList(int pageNum) {
		
		Pageable pageable = PageRequest.of(pageNum-1, 10);
		Page<Memo> result = memoRepository.findAll(pageable);
		
		int pageCount = result.getTotalPages();
		List<Memo> list = result.getContent();
		long element = result.getTotalElements();
		
	
		return result;
	}

	@Override
	public Memo getoneList(int mno) {
	    Optional<Memo> result = memoRepository.findById((long) mno);
	    if (result.isPresent()) {
	        return result.get();  
	    } else {
	        return null; 
	    }
	}

	
	
	

	
	
}
