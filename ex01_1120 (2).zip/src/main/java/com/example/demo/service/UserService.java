package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.UserDto;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;


@Service
public class UserService implements IUserService{
	
	private final UserRepository userRepository;

    // 생성자 주입 (자동으로 @Autowired 처리됨)
    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    
	@Override
	public User registeruser(UserDto userdto) {
		
		User user = User.builder()
				.userid(userdto.getId())
				.pw(userdto.getPw())
				.name(userdto.getName())
				.build();
		
		return userRepository.save(user);
	}


	@Override
	public User getUserById(String userid) {
		Optional<User> user = userRepository.findById(userid);
		return user.orElse(null);
	}

}
