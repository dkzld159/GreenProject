package com.example.demo.service;

import java.util.List;
import java.util.Map;

import org.springframework.data.domain.Page;

import com.example.demo.dto.MemoDto;
import com.example.demo.entity.Memo;

public interface IMemoService {
	
	public Memo register(MemoDto memoDto);
	public List<Memo> getList();
	public List<Memo> MyMemoList(String writer);
	public Page<Memo> getPageList(int pagenum); 
	public Memo getoneList(int mno);
 	
}
