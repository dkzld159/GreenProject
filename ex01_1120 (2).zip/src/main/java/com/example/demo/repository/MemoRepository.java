package com.example.demo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.entity.Memo;

public interface MemoRepository extends JpaRepository<Memo, Long>{
	
	//jpa리파지토리 상속을 받아야된다. 
	//타입파라미터 집어 넣어야됨, extends JpaRepository<Memo, Long> 
	//앞자리는 entity, 두번쨰는 아이디 타입 = 프라이머리키 타입
	
	List<Memo> findByWriter(String writer);

	Page<Memo> findByMnoBetween(long from, long to, Pageable pageable);

	void deleteMemoByMnoLessThan(Long mno);
	
	/* JPQL*/

	// JPQL
		   @Query("SELECT m FROM Memo m")
		   List<Memo> getList();   // 자바 객체(엔티티)에 보냄
		   
		   // :이 파라미터 처리 할 때 사용하는 기호이다.
		   @Query("SELECT m FROM Memo m WHERE m.mno = :mno")
		   Memo getMemo(@Param("mno")Long mno);
		   
		   @Query("SELECT COUNT(*) FROM Memo m")
		   int getCount();
		   
		   @Query("SELECT m FROM Memo m WHERE m.memoText LIKE :keyword")
		   List<Memo> getListWithKeyword(@Param("keyword") String keyword);
		   
		   @Query("SELECT m FROM Memo m WHERE m.memoText LIKE CONCAT ('%', :keyword, '%')")
		   List<Memo> getListWithKeyword2(@Param("keyword") String keyword);
		   
		   @Transactional
		   @Modifying
		   @Query("UPDATE Memo m SET m.memoText = :#{#param.memoTetxt}, m.writer = :#{#param.writer} WHERE m.mno = :#{#param.mno}")
		   int updateMemo(@Param("param")Memo memo);
		   
		   @Transactional
		   @Modifying
		   @Query("INSERT INTO Memo m (m.memoText, m.writer) VALUES (:#{#param.memoText}, :#{#param.writer})")
		   int insertMemo(@Param("param")Memo memo);
		   
		   @Transactional
		   @Modifying
		   @Query("DELETE FROM Memo m WHERE m.mno = ?1")   //?1 이라고 쓰면 뒤에 mno 가 자동으로 나온다.
		   int deleteMemo(Long mno);
		   
		   
		   
		   
		   
		   
		   
		   //Native Query
		   @Query(value="select * from tbl_memo", nativeQuery = true)
		   List<Memo> getListNative();
		   
		   
		   
		   
		}
