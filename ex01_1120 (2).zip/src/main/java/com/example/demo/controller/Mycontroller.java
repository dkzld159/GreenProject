package com.example.demo.controller;

import java.net.http.HttpRequest;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dto.MemoDto;
import com.example.demo.dto.UserDto;
import com.example.demo.entity.Memo;
import com.example.demo.entity.User;
import com.example.demo.service.MemoService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class Mycontroller {
	
	@Autowired
	UserService userservice;
	
	@Autowired
	MemoService memoservice;
	

	@RequestMapping("/")
	public String main(HttpSession session, Model model) {
	    String userId = (String)session.getAttribute("userId");
	   
	    session.setAttribute("userId", userId);
	   
	    return "main";
	}
	
	@RequestMapping("/registForm")
	public String requestForm() {
		return "registForm";
	}
	
	
	@RequestMapping("/regist")
	public String regist(UserDto userdto) {
		userservice.registeruser(userdto);
		return "main";
	}
	
	
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	
	
	@RequestMapping("/loginForm")
	public String login(@RequestParam("id") String id, 
	                    @RequestParam("pw") String pw,
	                    HttpServletRequest request, 
	                    Model model) {
	   
	    User user = userservice.getUserById(id); 
	    
	    if (user != null && user.getUserid().equals(id) && user.getPw().equals(pw)) {
	        request.getSession().setAttribute("userId", id);
	        System.out.println("로그인 성공: " + id);  // 로그인 후 userId 출력
	        return "main";
	    } else {
	        model.addAttribute("error", "id, pw 둘 중 오류");
	        return "loginForm";
	    }
	}

	
	@RequestMapping("/memoRegistForm")
	public String memoRegistForm(HttpSession session) {
		String userId = (String)session.getAttribute("userId");
		
		if(userId != null) {
			return "memoRegistForm";
		}else {
			return "login";
		}
		
	}
	
	@RequestMapping("/registmemo")
	public String registmemo(MemoDto memodto) {
		memoservice.register(memodto);
		return "redirect:/memoList/1";
	}
	
	
	
	@RequestMapping("/memoList/{pageNum}")
	public String memoList(Model model, @PathVariable("pageNum") int pageNum) {
	  
		Page<Memo> page = memoservice.getPageList(pageNum);
	
	   List<Memo> pagelist =  page.getContent();   //List<Memo>를 반환
	
	
	   
	   System.out.println(pagelist + "sdfsdfsdf");
	   System.out.println("sdfsdf"+ page.getTotalPages());

	   model.addAttribute("pagelist", pagelist);
	   model.addAttribute("currentPage", page.getNumber() + 1);  
	   model.addAttribute("totalPages", page.getTotalPages());
	  

	    return "memoList";  
	}

	
	@RequestMapping("/myMemoList/{userId}")
	public String myMemoList(@PathVariable("userId") String userid,
							Model model) {
		List<Memo>memolist = memoservice.MyMemoList(userid);
	
		model.addAttribute("memolist",memolist);
		return "/mymemoList";
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.removeAttribute("userId");
		return "redirect:/";
	}

	
	
	@RequestMapping("/detail/{mno}")
	public String logout(@PathVariable("mno") int mno,
							Model model) {
		Memo oneget =  memoservice.getoneList(mno);
		model.addAttribute("oneget",oneget);
		System.out.println(oneget+"sdfsdfsdf");
		return "/detail";
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
