package com.example.demo.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@ToString
@Entity 
@Table(name = "tbl_memo")
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class Memo {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long mno;
	//식별자 id, auto increament넣어줌 
	
	@Column(length = 200, nullable = false)
	private String memoText;
	@Column(length = 200, nullable = false)
	private String writer;
	//entity는 기본생성자 필요, jpa가 관리함. 
	//객체가 생성할떄 데이터를 생성할거고 그이후에는 게터만 사용
	// Hibernate: dbms관리해주는애
}
