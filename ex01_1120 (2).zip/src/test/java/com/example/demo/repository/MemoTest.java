package com.example.demo.repository;

import java.util.List;
import java.util.stream.IntStream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.annotation.Commit;

import com.example.demo.entity.Memo;

import jakarta.transaction.Transactional;

@SpringBootTest
class MemoTest {

	@Autowired
	MemoRepository memoRepository;
	
	@Autowired
	UserRepository userRepository;
	@Commit
	@Transactional //이안에서만 성공이 되어야지 반영이 된다. 
	//@Test
	void testDeleteQueryMethod() {
		memoRepository.deleteMemoByMnoLessThan(10L);
	}
	
	//@Test
	void testInsertDummies() {
		/*for (int i = 1; i < 100; i++) {
			Memo memo = Memo.builder().memoText("Sample.."+i).build();
			memoRepository.save(memo);
		}*/
		
		IntStream.rangeClosed(101, 200).forEach(i->{
			Memo memo = Memo.builder().memoText("Sample.."+i).build();
			memoRepository.save(memo);
		});
	}
	
	
//	@Test
//	void testSelect() {
//		Long mno = 100L;
//		Optional<Memo> result = memoRepository.findById(mno);
//		//optional null인지 아닌지 판단.
//		//null이면 nullexction발생
//		if(result.isPresent()) {
//			Memo memo = result.get();
//			//get이라는 메소드를 통해서 꺼냄. 
//			
//			System.out.println("memo"+memo);
//		}
//	}
	
//	
//	@Test
//	void testSelectAll() {
//		List<Memo> result =memoRepository.findAll();
//			for(Memo memo : result) {
//				System.out.println(memo);
//		}
//	}
	
	
//	@Test
//	void testUpdate() {
//		Memo memo = Memo.builder().mno(100L).memoText("Update Text").build();
//		System.out.println(memoRepository.save(memo));
//	}
//	//찾아서 insert,update
	
	
	//@Test
	void testDelete() {
		Long mno = 100L;
		memoRepository.deleteById(mno);
	}
	
//	@Test
//	void testQueryMethod1() {
//		List<Memo> result = memoRepository.findByMnoBetweenOrderByMnoDesc(70L, 80L);
//		for(Memo memo : result) {
//			System.out.println(memo);
//		}
//	}
	
	//@Test
	void testQueryMethodWithPageable() {
	Pageable  pageable = (Pageable) PageRequest.of(0, 10,Sort.by("mno"));
	Page<Memo> result = memoRepository.findByMnoBetween(10L,50L,pageable);
	result.get().forEach(memo->System.out.println(memo));
	}
	
	
	//@Test
	void testSort() {
		Sort sort = Sort.by("mno").descending();
		Sort sort2 = Sort.by("memo_text").ascending();
		Sort sortAll = sort.and(sort);
		Pageable pageable = PageRequest.of(0, 10, sortAll);

		Page<Memo> result = memoRepository.findAll(pageable);
		result.get().forEach(memo-> {
			System.out.println(memo);
		});
		
		
	}
	
	
	
	//@Test
	void testPageDefault() {
		//1.페이지 10개
		Pageable pageable = PageRequest.of(0, 10);
		Page<Memo> result = memoRepository.findAll(pageable);
		System.out.println(result);
		System.out.println("```````````````");
		System.out.println("Total page : "+result.getTotalPages());//총페이지 개수 
		System.out.println("Total count" + result.getTotalElements()); //전체 개수
		System.out.println("Page Number" +result.getNumber()); //현재 페이지 번호(0부터 시작)
		System.out.println("Page Size : " +result.getSize()); //페이지당 데이터 개수 
		System.out.println("has next page"+result.hasNext()); //다음페이지 존재 여부 
		System.out.println("first page? " +result.isFirst()); //시작 페이지(0) 여부 
		System.out.println("----------------------");
		
		for (Memo memo : result.getContent()) {
			System.out.println(memo);
		}
		
	} 
	

	//@Test
	void testJpql() {
		List<Memo> list = memoRepository.getList();
		for (Memo memo : list) {
			System.out.println(list);
		}
	}
	
	//@Test
	void testJpql2() {
		 Memo mno = memoRepository.getMemo(10L);
		System.out.println(mno);
	}
	
	//@Test
	void testJpal3() {
		int mcount = memoRepository.getCount();
		System.out.println(mcount);
	}
	
	//엔티티는 중간역할을 해서 데이터를 주고받는데 영속성 컨텍스트
	
	
	
	//@Test
	void testJpql4() {
		List<Memo> list= memoRepository.getListWithKeyword2("%11%");
		System.out.println(list);
	
	}
	
	
	
	//@Test
	void testobjectList() {
		
		List<Object[]> list = userRepository.getUserJoinMemo();
		
		for (Object[] object : list) {
			System.out.println(object);
		}
	}
	
	
	
	
	
	@Test
	void testNativeQuery() {
		List<Memo> list = memoRepository.getListNative();
		
		for (Memo memo : list) {
			System.out.println(memo);
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
