package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.hibernate.type.descriptor.java.CharacterArrayJavaType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.controller.dao.IuserDao;
import com.example.demo.dto.UserDto;

@Service
public class userService implements IuserDao{

	@Autowired
	IuserDao userdao;
	
	@Override
	public UserDto getUser(String id, String pass) {
		//아이디를 갖고오거야
		UserDto getuser= userdao.getUser(id,pass);
		System.out.println(getuser + "sdfsdf!!!");
		List<String> randompw = new ArrayList<>();
		
		for(char password : pass.toCharArray()) {
			int ASCpw = (int)password;
			randompw.add(String.valueOf(ASCpw));
		}
		String hash = String.join("", randompw)+ getuser.getNum();
		System.out.println("키값" +randompw);
		System.out.println("해시" +hash);
		
		if(getuser.getUserPassword().equals(hash)) {
			return getuser;
		}
		return null;
	}


	@Override
	public int insertuser(UserDto userdto) {
		Random random = new Random();
	    int key = random.nextInt(10) +1;
	    
		String pw 	=	userdto.getUserPassword();
		List<String> randompw = new ArrayList<>();
	   
		for(char password : pw.toCharArray()) {
			int ASCpw = (int)password;
			randompw.add(String.valueOf(ASCpw));
			System.out.println(randompw);
		}
		String hash = String.join("",randompw) +key;
	
		System.out.println("키값부여!!!! " + hash);
		userdto.setUserPassword((String.valueOf(hash)));
		
        char lastChar = hash.charAt(hash.length() - 1);
        userdto.setNum(key);
        System.out.println("sdf"+lastChar);
        
		int result = userdao.insertuser(userdto); 
	    return result;
	}


	
}
