package com.example.demo.controller.dao;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.dto.UserDto;

@Mapper
public interface IuserDao {
	
	
  public int insertuser(@Param("user") UserDto userdto);
  public UserDto getUser(@Param("userId") String id ,@Param("userPassword")  String pass);
  

}
