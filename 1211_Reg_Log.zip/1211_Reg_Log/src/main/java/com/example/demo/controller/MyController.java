package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.BeanDefinitionDsl.Role;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.dto.CustomSesession;
import com.example.demo.dto.UserDto;

import com.example.demo.service.userService;

import jakarta.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MyController {
	
	@Autowired
	private userService userservice;
	
	@RequestMapping("/")
	public String main() {
		return "/registForm";
	}
	@RequestMapping("/admin")
	public String adminP() {
		return "/admin";
	}
	
	@RequestMapping("/member")
	public String member() {
		return "/member";
	}
	
	@RequestMapping("/insertuser")
	public String insertuser(UserDto userdto, Model model) {
		
		System.out.println(userdto + "sdfsdfsdf");
		userservice.insertuser(userdto);
		return "/login";
	}
	
	
	@RequestMapping("/login")
	public String userDto() {
		return "/login";
	}
	
	@RequestMapping("/loginForm")
	public String loginForm(@RequestParam("userId") String id, 
	                        @RequestParam("userPassword") String password,
	                        CustomSesession userinfo,
	                        RedirectAttributes redirect) {
	    
	    UserDto userlogin = userservice.getUser(id,password);
	    System.out.println("getuser" +userlogin);
	  
	    CustomSesession userinfo1 = new CustomSesession(userlogin);
	    System.out.println(userinfo1 + "sdfsdf");
	    redirect.addFlashAttribute("userId", userinfo1.getUserdto().getUserId());
	  
	    if ("admin".equals(userlogin.getRole())) {
	        return "redirect:/admin";  
	    } else if ("member".equals(userlogin.getRole())) {
	        return "redirect:/member";  
	    }

	    return "redirect:/main"; 
	}
	
}
	
	




