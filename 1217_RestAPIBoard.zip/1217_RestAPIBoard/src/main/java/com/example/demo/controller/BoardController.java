package com.example.demo.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dao.IBoardDao;
import com.example.demo.domain.Board;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/board-api")
public class BoardController {

	
	@Autowired
	IBoardDao iboard;
	
	//get http://localhost:8091/board-api/board
	
	@Value("${spring.servlet.multipart.location:./uploads}")
	private String uploadPath;

	 @PostMapping("/boardInsert")
	    public ResponseEntity<Map<String, Object>> boardInsert(Board board, @RequestParam("file") MultipartFile file) {
	        Map<String, Object> response = new HashMap<>();

	        String filename = file.getOriginalFilename();
	        File uploadFile = new File(uploadPath + File.separator + filename);

	        try {
	            file.transferTo(uploadFile);  
	            response.put("success", true);
	            response.put("message", "등록완료");
	            response.put("filename", filename);
	        } catch (IOException e) {
	            e.printStackTrace();
	            response.put("success", false);
	            response.put("message", "파일 업로드 실패");
	        }

	        board.setFilename(filename);
	        iboard.boardInsert(board);

	        return ResponseEntity.ok(response);
	    }
	 
	 @GetMapping("/getboardList")
	    public ResponseEntity<List<Board>> getBoardList() {
	        List<Board> boards = iboard.getBoards();
	        return ResponseEntity.ok(boards); // 200 OK와 함께 데이터 반환
	    }
	 
	
	//restController안쓸경우 
//	 @PostMapping("/createBoard")
//	 public ResponseEntity<Board> createBoard(@RequestBody Board board) {
//	     // 클라이언트에서 보낸 JSON 데이터가 Board 객체로 자동 변환됩니다.
//	     boardService.save(board);
//	     return ResponseEntity.ok(board);
//	 }
	 
	 
	 //서버에서 반환하는 데이터를 자동으로 JSON 형식으로 변환하여 클라이언트로 보내는 역할
//	 @GetMapping("/getBoard/{id}")
//	 @ResponseBody
//	 public Board getBoard(@PathVariable Long id) {
//	     Board board = boardService.findById(id);
//	     return board;  // 이 객체는 JSON으로 자동 변환되어 클라이언트로 전달됩니다.
//	 }
}
