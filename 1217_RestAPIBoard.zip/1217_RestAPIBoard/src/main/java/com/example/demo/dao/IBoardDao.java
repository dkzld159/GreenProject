package com.example.demo.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.example.demo.domain.Board;

@Mapper
public interface IBoardDao {
	int boardInsert(@Param("board")Board board);
	List<Board> getBoards();
	
}
