package com.example.demo.domain;

import java.sql.Timestamp;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Board {
	
	private String bnum;
	private String title;
	private String content;
	private String filename;
	private Timestamp createdAt;
	private Timestamp updatedAt;
}
