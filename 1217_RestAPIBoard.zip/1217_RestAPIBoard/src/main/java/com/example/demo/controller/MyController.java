package com.example.demo.controller;


import com.example.demo.domain.Board;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class MyController {
	@RequestMapping("/")
	public String root() {
		return "/main";
	}
	
	@GetMapping("/boardList")
	public String boardInsert() {
		return "/boardList";
	}
	
	
	@GetMapping("/boardForm")
	public String boardForm(Board board) {
		return "/boardForm";
	}
	
	@GetMapping("/boardRegist")
	public String boardregist(Board board) {
		return "/board-api/boardInsert";
	}
	
	
}
